#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <LSM6DSV16XSensor.h>

#define CS_PIN 0
#define INT1_pin 6

#define SENSOR_ODR 7680.0f // In Hertz
#define ACC_FS 8 // In g
#define GYR_FS 2000 // In dps
#define MEASUREMENT_TIME_INTERVAL (1000.0f/SENSOR_ODR) // In ms
#define FIFO_SAMPLE_THRESHOLD 199
#define FLASH_BUFF_LEN 8192

#define SIZEOF_DATA 12 // 3 x 4 bytes per value
#define BUFF_N_DATA 20 // 20 datapoints per buffer

#define BUFF_LEN (SIZEOF_DATA * BUFF_N_DATA)

/* accelerometer object */
LSM6DSV16XSensor AccGyr(&SPI, CS_PIN, 8000000UL);
volatile uint8_t fullFlag = 0; // FIFO full flag
uint8_t status = 0;
unsigned long timestamp_count = 0;
bool acc_available = false;
bool gyr_available = false;
int32_t acc_value[3];
int32_t gyr_value[3];
uint8_t tag = 0;

/* USB buffer */
char buff0[BUFF_LEN];
char buff1[BUFF_LEN];
char buff_encoded[256];

uint32_t num_samp = 0;

/* buffer pointers */
int writing_i = 0;
int sending_i = 0;

int buff_i = 0;

size_t cobsEncode(const void *data, size_t length, char *buffer){
	char *encode = buffer; // Encoded byte pointer
	char *codep = encode++; // Output code pointer
	char code = 1; // Code value

	for (const char *byte = (const char *)data; length--; ++byte){
		if (*byte) // Byte not zero, write it
			*encode++ = *byte, ++code;

		if (!*byte || code == 0xff){ // Input is zero or block completed, restart
			*codep = code, code = 1, codep = encode;
			if (!*byte || length)
				++encode;
		}
	}
	*codep = code;  // Write final code value
	return encode - buffer;
}

void setup(void) {
  Serial.begin(250000);

  delay(500);

  SPI.begin();
  attachInterrupt(INT1_pin, INT1_fullEvent_cb, RISING);

  // Initialize LSM6DSV16X.
  AccGyr.begin();

  status |= AccGyr.Device_Reset();

  status |= AccGyr.Enable_X();
  status |= AccGyr.Enable_G();

  // Configure ODR and FS of the acc and gyro
  status |= AccGyr.Set_X_ODR(SENSOR_ODR);
  status |= AccGyr.Set_X_FS(ACC_FS);
  status |= AccGyr.Set_G_ODR(SENSOR_ODR);
  status |= AccGyr.Set_G_FS(GYR_FS);

  // Configure FIFO BDR for acc and gyro
  status |= AccGyr.FIFO_Set_X_BDR(SENSOR_ODR);
  status |= AccGyr.FIFO_Set_G_BDR(SENSOR_ODR);

  // Set Set FIFO watermark level
  status |= AccGyr.FIFO_Set_Watermark_Level(FIFO_SAMPLE_THRESHOLD);
  // Set FIFO stop on watermark level
  status |= AccGyr.FIFO_Set_Stop_On_Fth(1);
  // Enable FIFO full interrupt on sensor INT1 pin
  status |= AccGyr.Set_INT1_DRDY_XL(1);
  //status |= AccGyr.FIFO_Set_INT1_FIFO_Full(1);
  // Set FIFO in Continuous mode
  status |= AccGyr.FIFO_Set_Mode(LSM6DSV16X_STREAM_MODE);

  if (status != LSM6DSV16X_OK) {
    while (1);
  }
}

void loop(void) {
  static int i = 0;
  if (writing_i != sending_i) {
    // time to send
    char* buff = sending_i ? buff1 : buff0;

    size_t length_encoded = cobsEncode(buff, BUFF_LEN, buff_encoded);
    buff_encoded[length_encoded] = '\0';

    Serial.write(buff_encoded, length_encoded+1);

    sending_i = !sending_i;
  }
}

void INT1_fullEvent_cb() {
  num_samp++;
  AccGyr.FIFO_Get_Tag(&tag);
  AccGyr.Get_X_Axes(acc_value);

  unsigned char* p1 = reinterpret_cast<unsigned char*>(&acc_value);
  unsigned char* p2 = reinterpret_cast<unsigned char*>(&num_samp);

  char* buff = writing_i ? buff1 : buff0;

  int i;

  for (i = 0; i < 12; i++) {
    buff[buff_i+i] = p1[i];
  }

  buff_i += SIZEOF_DATA;

  if (buff_i >= BUFF_LEN) {
    writing_i = !writing_i;
    buff_i = 0;
  }
}
