# LSM6DSV16X-xiao

This is a minimal example of using a LSM6DSV16X in SPI mode with a xiao rp2040 module.

## Schematic

![](img/schematic.png)

## Board

![](img/board.png)

## Assembly

The 3D printed case protects the electronics and goes on top of the circuit. A steel plate can be placed under the PCB to make it compatible with magnets. The assembly is completed with M3 screws.

![](img/assembly.jpg)

Here is the finished assembly mounted on the spindle of Haas Mini Mill:

![](img/mounting.jpg)

## Code

example code can be found [here](./code/).
